ALTER TABLE user add n_mail_user varchar(100);
ALTER TABLE user add i_phone_user integer;
ALTER TABLE user add i_cellphone_user integer;
ALTER TABLE user add n_password varchar(30);
ALTER TABLE user add n_role_user varchar(100);

ALTER TABLE ticket_on_air add n_round integer;
ALTER TABLE ticket_on_air add d_finish datetime;
ALTER TABLE ticket_on_air add d_temporal datetime;
ALTER TABLE follow_up_12h add n_round integer;
ALTER TABLE follow_up_24h add n_round integer;
ALTER TABLE follow_up_36h add n_round integer;
ALTER TABLE scaled_on_air add n_round integer;

ALTER TABLE ticket_on_air add d_actualizacion_final datetime;
ALTER TABLE ticket_on_air add d_asignacion_final datetime;

ALTER TABLE on_air_12h add n_comentario varchar(1000);
ALTER TABLE on_air24h add n_comentario varchar(1000);
ALTER TABLE on_air_36h add n_comentario varchar(1000);

ALTER TABLE preparation_stage add n_evidenciatg varchar(100);
ALTER TABLE ticket_on_air modify i_lider_cambio varchar(100);
ALTER TABLE ticket_on_air modify i_lider_cuadrilla varchar(100);

ALTER TABLE `on_air_12h`
	ADD COLUMN `d_start12h` TIMESTAMP NULL DEFAULT NULL AFTER `k_id_onair`,
	CHANGE COLUMN `n_comentario` `n_comentario` VARCHAR(1000) NULL DEFAULT NULL AFTER `d_fin12h`,
	ADD COLUMN `i_timestamp` BIGINT NOT NULL DEFAULT '0' AFTER `n_comentario`,
	ADD COLUMN `i_round` INT NOT NULL DEFAULT '0' AFTER `i_timestamp`,
	ADD COLUMN `d_created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP AFTER `i_round`;

ALTER TABLE `on_air24h`
	ADD COLUMN `d_start24h` TIMESTAMP NULL DEFAULT NULL AFTER `k_id_onair`,
	CHANGE COLUMN `n_comentario` `n_comentario` VARCHAR(1000) NULL DEFAULT NULL AFTER `d_fin24h`,
	ADD COLUMN `i_timestamp` BIGINT NOT NULL DEFAULT '0' AFTER `n_comentario`,
	ADD COLUMN `i_round` INT NOT NULL DEFAULT '0' AFTER `i_timestamp`,
	ADD COLUMN `d_created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP AFTER `i_round`;

ALTER TABLE `on_air_36h`
	ADD COLUMN `d_start36h` TIMESTAMP NULL DEFAULT NULL AFTER `k_id_onair`,
	CHANGE COLUMN `n_comentario` `n_comentario` VARCHAR(1000) NULL DEFAULT NULL AFTER `d_fin36h`,
	ADD COLUMN `i_timestamp` BIGINT NOT NULL DEFAULT '0' AFTER `n_comentario`,
	ADD COLUMN `i_round` INT NOT NULL DEFAULT '0' AFTER `i_timestamp`,
	ADD COLUMN `d_created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP AFTER `i_round`;

	ALTER TABLE ticket_on_air add i_precheck_realizado integer;
	ALTER TABLE scaled_on_air add n_atribuible_nokia varchar(100);
	ALTER TABLE scaled_on_air add n_atribuible_nokia2 varchar(100);

-- SE AGREGA UN CAMPO A LAS TABALS DE DETALLES
ALTER TABLE `on_air_12h`
	ADD COLUMN `i_state` TINYINT(1) NOT NULL DEFAULT b'0' AFTER `i_round`;

ALTER TABLE `on_air24h`
	ADD COLUMN `i_state` TINYINT(1) NOT NULL DEFAULT b'0' AFTER `i_round`;

ALTER TABLE `on_air_36h`
	ADD COLUMN `i_state` TINYINT(1) NOT NULL DEFAULT b'0' AFTER `i_round`;

ALTER TABLE `on_air_12h`
	ADD COLUMN `i_percent` TINYINT(1) NOT NULL DEFAULT '0' AFTER `i_round`;

ALTER TABLE `on_air24h`
	ADD COLUMN `i_percent` TINYINT(1) NOT NULL DEFAULT '0' AFTER `i_round`;

ALTER TABLE `on_air_36h`
	ADD COLUMN `i_percent` TINYINT(1) NOT NULL DEFAULT '0' AFTER `i_round`;

ALTER TABLE preparation_stage add n_comentario_doc varchar(1000);
ALTER TABLE ticket_on_air add n_comentario_coor varchar(1000);
ALTER TABLE precheck add n_comentario_ing varchar(1000);


-- SE AGREGA UNA COLUMNA EN LAS TABLAS DE DETALLES (13/11/2017):
ALTER TABLE `on_air_12h`
	ADD COLUMN `d_start_temp` TIMESTAMP NULL DEFAULT NULL AFTER `d_start12h`;

ALTER TABLE `on_air24h`
	ADD COLUMN `d_start_temp` TIMESTAMP NULL DEFAULT NULL AFTER `d_start24h`;

ALTER TABLE `on_air_36h`
	ADD COLUMN `d_start_temp` TIMESTAMP NULL DEFAULT NULL AFTER `d_start36h`;


ALTER TABLE ticket_on_air add i_actualEngineer integer;

-- (Mar, 14/Nov/2017) SE AGREGA UNA COLUMNA EN LAS TABLAS DE DETALLES PARA MANIPULAR LAS HORAS QUE DURAN LAS PRORROGAS...
ALTER TABLE `on_air_12h`
	ADD COLUMN `i_hours` INT NULL DEFAULT '0' AFTER `i_state`;

ALTER TABLE `on_air24h`
	ADD COLUMN `i_hours` INT NULL DEFAULT '0' AFTER `i_state`;

ALTER TABLE `on_air_36h`
	ADD COLUMN `i_hours` INT NULL DEFAULT '0' AFTER `i_state`;
-- Se eliminan estados 14/11/2017

DELETE FROM `on_air`.`status_on_air` WHERE `k_id_status_onair`='3';
DELETE FROM `on_air`.`status_on_air` WHERE `k_id_status_onair`='9';
DELETE FROM `on_air`.`status_on_air` WHERE `k_id_status_onair`='19';
DELETE FROM `on_air`.`status_on_air` WHERE `k_id_status_onair`='24';
DELETE FROM `on_air`.`status_on_air` WHERE `k_id_status_onair`='30';
DELETE FROM `on_air`.`status_on_air` WHERE `k_id_status_onair`='41';
DELETE FROM `on_air`.`status_on_air` WHERE `k_id_status_onair`='46';
DELETE FROM `on_air`.`status_on_air` WHERE `k_id_status_onair`='47';
DELETE FROM `on_air`.`status_on_air` WHERE `k_id_status_onair`='51';
DELETE FROM `on_air`.`status_on_air` WHERE `k_id_status_onair`='52';
DELETE FROM `on_air`.`status_on_air` WHERE `k_id_status_onair`='55';
DELETE FROM `on_air`.`status_on_air` WHERE `k_id_status_onair`='56';
DELETE FROM `on_air`.`status_on_air` WHERE `k_id_status_onair`='57';
DELETE FROM `on_air`.`status_on_air` WHERE `k_id_status_onair`='60';
DELETE FROM `on_air`.`status_on_air` WHERE `k_id_status_onair`='61';
DELETE FROM `on_air`.`status_on_air` WHERE `k_id_status_onair`='62';
DELETE FROM `on_air`.`status_on_air` WHERE `k_id_status_onair`='66';
DELETE FROM `on_air`.`status_on_air` WHERE `k_id_status_onair`='67';

/*==============================================================*/
/* table: reporte_comentario                                                 */
/*==============================================================*/
CREATE TABLE IF NOT EXISTS `reporte_comentario` (
	`k_id_primary` int not null AUTO_INCREMENT,
  `k_id_on_air` int(11) DEFAULT NULL,
  `n_nombre_estacion_eb` varchar(100) DEFAULT NULL,
  `n_tecnologia` varchar(100) DEFAULT NULL,
  `n_banda` varchar(100) DEFAULT NULL,
  `n_tipo_trabajo` varchar(100) DEFAULT NULL,
  `n_estado_eb_resucomen` varchar(100) DEFAULT NULL,
  `comentario_resucoment` varchar(2000) DEFAULT NULL,
  `hora_actualizacion_resucomen` timestamp NULL DEFAULT NULL,
  `usuario_resucomen` varchar(100) DEFAULT NULL,
  `ente_ejecutor` varchar(100) DEFAULT NULL,
  `tipificacion_resucomen` varchar(100) DEFAULT NULL,
  `noc` varchar(100) DEFAULT NULL,
	primary key (k_id_primary)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


ALTER TABLE ticket_on_air modify n_estadoonair varchar(100) DEFAULT 'NO ON AIR';

-- (15 nov 2017) se modifica el campo time_escalado
ALTER TABLE scaled_on_air modify d_time_escalado varchar(100);

ALTER TABLE preparation_stage modify n_comentarioccial varchar(1000);
ALTER TABLE ticket_on_air modify n_kpis_degraded varchar(1000);
ALTER TABLE ticket_on_air modify i_valor_kpi1 varchar(100);
ALTER TABLE ticket_on_air modify i_valor_kpi2 varchar(100);
ALTER TABLE ticket_on_air modify i_valor_kpi3 varchar(100);
ALTER TABLE ticket_on_air modify i_valor_kpi4 varchar(100);
ALTER TABLE ticket_on_air modify n_en_prorroga varchar(100) DEFAULT 'FALSE';
ALTER TABLE ticket_on_air modify b_excpetion_gri varchar(100);
ALTER TABLE preparation_stage modify b_vistamm varchar(100);


/* MODIFICACIONES 16/11/2017 */
ALTER TABLE ticket_on_air add i_priority varchar(10);

/* MODIFICACIONES 16/Nov/2017 05:54 pm */
ALTER TABLE `ticket_on_air`
	ADD COLUMN `d_created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP AFTER `i_priority`;

ALTER TABLE `ticket_on_air`
	ADD COLUMN `d_precheck_init` TIMESTAMP NULL DEFAULT NULL AFTER `i_priority`;

	INSERT INTO `on_air`.`substatus` (`k_id_substatus`, `n_name_substatus`) VALUES ('31', 'Notificacion');
	INSERT INTO `on_air`.`status_on_air` (`k_id_status_onair`, `k_id_substatus`, `k_id_status`) VALUES ('91', '31', '9');



	/* MODIFICACIONES 17/11/2019 */
	ALTER TABLE ticket_on_air modify n_round integer DEFAULT '1';

/* Modificaciones 19/11/2017 */
ALTER TABLE ticket_on_air add n_implementacion_remota varchar(100);
INSERT INTO `on_air`.`status_on_air` (`k_id_status_onair`, `k_id_substatus`, `k_id_status`) VALUES ('98', '8', '9');

/*ALTER TABLE preparation_stage AUTO_INCREMENT = 1;
ALTER TABLE ticket_on_air AUTO_INCREMENT = 1;
ALTER TABLE scaled_on_air AUTO_INCREMENT = 1;
ALTER TABLE scaled AUTO_INCREMENT = 1;
ALTER TABLE precheck AUTO_INCREMENT = 1;
ALTER TABLE on_air_36h AUTO_INCREMENT = 1;
ALTER TABLE on_air_12h AUTO_INCREMENT = 1;
ALTER TABLE on_air24h AUTO_INCREMENT = 1;
ALTER TABLE follow_up_36h AUTO_INCREMENT = 1;
ALTER TABLE follow_up_24h AUTO_INCREMENT = 1;
ALTER TABLE follow_up_12h AUTO_INCREMENT = 1;*/


/*use on_air;
delete from on_air_12h where k_id_12h_real > 0;
delete from on_air24h where k_id_24h_real > 0;
delete from on_air_36h where k_id_36h_real > 0;

delete from follow_up_12h where k_id_follow_up_12h > 0;
delete from follow_up_24h where k_id_follow_up_24h > 0;
delete from follow_up_36h where k_id_follow_up_36h > 0;

delete from scaled where k_id_sacled > 0;
delete from scaled_on_air where k_id_scaled_on_air > 0;

delete from ticket_on_air where k_id_onair > 0;

delete from preparation_stage where k_id_preparation > 0;
delete from precheck where k_id_precheck > 0;

delete from reporte_comentario where k_id_primary > 0;
*/

-- Modificaciones Lunes, 20 de Noviembre de 2017.
ALTER TABLE `ticket_on_air`
	CHANGE COLUMN `d_created_at` `d_created_at` TIMESTAMP NULL DEFAULT NULL AFTER `d_precheck_init`;

ALTER TABLE `user`
	ADD COLUMN `n_code_user` VARCHAR(5) NULL DEFAULT NULL AFTER `k_id_user`,
	ADD UNIQUE INDEX `n_code_user` (`n_code_user`);


-- Actualizaciones Miércoles, 22 de Noviembre 2017.
ALTER TABLE `on_air_12h`
	CHANGE COLUMN `n_comentario` `n_comentario` LONGTEXT NULL DEFAULT NULL AFTER `d_fin12h`;

ALTER TABLE `on_air24h`
	CHANGE COLUMN `n_comentario` `n_comentario` LONGTEXT NULL DEFAULT NULL AFTER `d_fin24h`;

ALTER TABLE `on_air_36h`
	CHANGE COLUMN `n_comentario` `n_comentario` LONGTEXT NULL DEFAULT NULL AFTER `d_fin36h`;


-- Actualizaciones 23, de Noviembre 2017.
ALTER TABLE `ticket_on_air`
	ADD COLUMN `i_stand_by_hours` INT NOT NULL DEFAULT '0' AFTER `d_precheck_init`;

ALTER TABLE `ticket_on_air`
	CHANGE COLUMN `i_stand_by_hours` `i_prorroga_hours` INT(11) NOT NULL DEFAULT '0' AFTER `d_precheck_init`;

INSERT INTO `on_air`.`status_on_air` (`k_id_status_onair`, `k_id_substatus`, `k_id_status`) VALUES ('100', '32', '9');

ALTER TABLE `ticket_on_air`
	ADD COLUMN `data_standby` VARCHAR(500) NULL AFTER `n_implementacion_remota`;

	/* 24 de nov 2017 */
	ALTER TABLE scaled_on_air add n_comentario_esc varchar(2000);

/*======================25 11 2017=============================*/
ALTER TABLE ticket_on_air	ADD  d_t_from_notif varchar(50);
ALTER TABLE ticket_on_air	ADD  d_t_from_asign varchar(50);
ALTER TABLE ticket_on_air	ADD  n_ola varchar(100);
ALTER TABLE ticket_on_air	ADD  n_ola_excedido varchar(100);
ALTER TABLE ticket_on_air	ADD  n_ola_areas varchar(100);
ALTER TABLE ticket_on_air	ADD  n_ola_areas_excedido varchar(100);

ALTER TABLE reporte_comentario modify comentario_resucoment varchar(5000);


-- Actualizaciones Lunes, 27 de noviembre de 2017.
ALTER TABLE `work`
	ADD COLUMN `b_aplica_bloqueo` BIT NULL DEFAULT b'0' AFTER `n_name_ork`;

ALTER TABLE `ticket_on_air`
	ADD COLUMN `n_json_sectores` VARCHAR(100) NULL DEFAULT NULL AFTER `n_sectoresdesbloqueados`;

-- Actualizaciones Miércoles, 29 de Noviembre de 2017.

-- Se actualiza la tabla Work.
UPDATE `work` SET b_aplica_bloqueo = 1 WHERE k_id_work = 21;
UPDATE `work` SET b_aplica_bloqueo = 1 WHERE k_id_work = 22;
UPDATE `work` SET b_aplica_bloqueo = 1 WHERE k_id_work = 23;
UPDATE `work` SET b_aplica_bloqueo = 1 WHERE k_id_work = 24;
UPDATE `work` SET b_aplica_bloqueo = 1 WHERE k_id_work = 25;
UPDATE `work` SET b_aplica_bloqueo = 1 WHERE k_id_work = 26;
UPDATE `work` SET b_aplica_bloqueo = 1 WHERE k_id_work = 29;
UPDATE `work` SET b_aplica_bloqueo = 1 WHERE k_id_work = 30;
UPDATE `work` SET b_aplica_bloqueo = 1 WHERE k_id_work = 31;
UPDATE `work` SET b_aplica_bloqueo = 1 WHERE k_id_work = 39;
UPDATE `work` SET b_aplica_bloqueo = 1 WHERE k_id_work = 40;
UPDATE `work` SET b_aplica_bloqueo = 1 WHERE k_id_work = 44;
UPDATE `work` SET b_aplica_bloqueo = 1 WHERE k_id_work = 45;
UPDATE `work` SET b_aplica_bloqueo = 1 WHERE k_id_work = 46;
UPDATE `work` SET b_aplica_bloqueo = 1 WHERE k_id_work = 47;
UPDATE `work` SET b_aplica_bloqueo = 1 WHERE k_id_work = 50;


-- Se agrega la tabla sectores.

-- Volcando estructura para tabla on_air.sectores
CREATE TABLE IF NOT EXISTS `sectores` (
  `k_id_sector` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(5) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`k_id_sector`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla on_air.sectores: ~45 rows (aproximadamente)
DELETE FROM `sectores`;
INSERT INTO `sectores` (`k_id_sector`, `name`, `created_at`) VALUES
	(1, '1', '2017-11-27 09:35:38'),
	(2, '2', '2017-11-27 09:35:40'),
	(3, '3', '2017-11-27 09:35:42'),
	(4, '4', '2017-11-27 09:35:43'),
	(5, '5', '2017-11-27 09:35:45'),
	(6, '6', '2017-11-27 09:35:48'),
	(7, 'A', '2017-11-27 09:36:01'),
	(8, 'B', '2017-11-27 09:36:03'),
	(9, 'C', '2017-11-27 09:36:04'),
	(10, 'X', '2017-11-27 09:36:15'),
	(11, 'Y', '2017-11-27 09:36:17'),
	(12, 'Z', '2017-11-27 09:36:19'),
	(13, 'U', '2017-11-27 09:36:21'),
	(14, 'V', '2017-11-27 09:36:33'),
	(15, 'W', '2017-11-27 09:36:34'),
	(16, 'Y1', '2017-11-27 09:36:51'),
	(17, 'Y2', '2017-11-27 09:36:53'),
	(18, 'Y3', '2017-11-27 09:36:55'),
	(19, 'Y4', '2017-11-27 09:36:59'),
	(20, 'Y5', '2017-11-27 09:37:01'),
	(21, 'Y6', '2017-11-27 09:37:06'),
	(22, 'I', '2017-11-27 09:37:08'),
	(23, 'J', '2017-11-27 09:37:10'),
	(24, 'K', '2017-11-27 09:37:12'),
	(25, 'L', '2017-11-27 09:37:14'),
	(26, 'M', '2017-11-27 09:37:16'),
	(27, 'N', '2017-11-27 09:37:18'),
	(28, 'O', '2017-11-27 09:37:23'),
	(29, 'P', '2017-11-27 09:37:24'),
	(30, 'Q', '2017-11-27 09:37:26'),
	(31, 'R', '2017-11-27 09:37:27'),
	(32, 'S', '2017-11-27 09:37:29'),
	(33, 'T', '2017-11-27 09:37:30'),
	(34, 'L1', '2017-11-27 09:37:32'),
	(35, 'L2', '2017-11-27 09:37:34'),
	(36, 'L3', '2017-11-27 09:37:36'),
	(37, 'L4', '2017-11-27 09:37:37'),
	(38, 'L5', '2017-11-27 09:37:41'),
	(39, 'L6', '2017-11-27 09:37:44'),
	(40, 'M1', '2017-11-27 09:37:46'),
	(41, 'M2', '2017-11-27 09:37:48'),
	(42, 'M3', '2017-11-27 09:37:51'),
	(43, 'M4', '2017-11-27 09:37:53'),
	(44, 'M5', '2017-11-27 09:37:55'),
	(45, 'M6', '2017-11-27 09:38:04');

-- Se agrega la tabla de relaciones de los sectores

-- Volcando estructura para tabla on_air.sectores_on_air
CREATE TABLE IF NOT EXISTS `sectores_on_air` (
  `k_id_sector_on_air` int(11) NOT NULL AUTO_INCREMENT,
  `k_id_sector` int(11) NOT NULL DEFAULT '0',
  `k_id_tecnology` int(11) DEFAULT NULL,
  `k_id_band` int(11) DEFAULT NULL,
  PRIMARY KEY (`k_id_sector_on_air`),
  KEY `k_id_tecnology` (`k_id_tecnology`),
  KEY `k_id_band` (`k_id_band`),
  KEY `k_id_sector` (`k_id_sector`),
  CONSTRAINT `FK_sectores_on_air_band` FOREIGN KEY (`k_id_band`) REFERENCES `band` (`k_id_band`),
  CONSTRAINT `FK_sectores_on_air_sectores` FOREIGN KEY (`k_id_sector`) REFERENCES `sectores` (`k_id_sector`),
  CONSTRAINT `FK_sectores_on_air_technology` FOREIGN KEY (`k_id_tecnology`) REFERENCES `technology` (`k_id_technology`)
) ENGINE=InnoDB AUTO_INCREMENT=178 DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla on_air.sectores_on_air: ~177 rows (aproximadamente)
DELETE FROM `sectores_on_air`;
/*!40000 ALTER TABLE `sectores_on_air` DISABLE KEYS */;
INSERT INTO `sectores_on_air` (`k_id_sector_on_air`, `k_id_sector`, `k_id_tecnology`, `k_id_band`) VALUES
	(1, 1, 1, 3),
	(2, 2, 1, 3),
	(3, 3, 1, 3),
	(4, 4, 1, 3),
	(5, 5, 1, 3),
	(6, 6, 1, 3),
	(7, 7, 1, 1),
	(8, 8, 1, 1),
	(9, 9, 1, 1),
	(10, 10, 4, 3),
	(11, 11, 4, 3),
	(12, 12, 4, 3),
	(13, 13, 4, 3),
	(14, 14, 4, 3),
	(15, 15, 4, 3),
	(16, 16, 4, 3),
	(17, 17, 4, 3),
	(18, 18, 4, 3),
	(19, 19, 4, 3),
	(20, 20, 4, 3),
	(21, 21, 4, 3),
	(22, 22, 4, 1),
	(23, 23, 4, 1),
	(24, 24, 4, 1),
	(25, 25, 4, 1),
	(26, 26, 4, 1),
	(27, 27, 4, 1),
	(28, 28, 4, 1),
	(29, 29, 4, 1),
	(30, 30, 4, 1),
	(31, 31, 4, 1),
	(32, 32, 4, 1),
	(33, 33, 4, 1),
	(34, 34, 6, 2),
	(35, 35, 6, 2),
	(36, 36, 6, 2),
	(37, 37, 6, 2),
	(38, 38, 6, 2),
	(39, 39, 6, 2),
	(40, 40, 6, 1),
	(41, 41, 6, 1),
	(42, 42, 6, 1),
	(43, 43, 6, 1),
	(44, 44, 6, 1),
	(45, 45, 6, 1),
	(46, 1, 1, 4),
	(47, 2, 1, 4),
	(48, 3, 1, 4),
	(49, 4, 1, 4),
	(50, 5, 1, 4),
	(51, 6, 1, 4),
	(52, 7, 1, 4),
	(53, 8, 1, 4),
	(54, 9, 1, 4),
	(55, 10, 4, 4),
	(56, 11, 4, 4),
	(57, 12, 4, 4),
	(58, 13, 4, 4),
	(59, 14, 4, 4),
	(60, 15, 4, 4),
	(61, 16, 4, 4),
	(62, 17, 4, 4),
	(63, 18, 4, 4),
	(64, 19, 4, 4),
	(65, 20, 4, 4),
	(66, 21, 4, 4),
	(67, 22, 4, 4),
	(68, 23, 4, 4),
	(69, 24, 4, 4),
	(70, 25, 4, 4),
	(71, 26, 4, 4),
	(72, 27, 4, 4),
	(73, 28, 4, 4),
	(74, 29, 4, 4),
	(75, 30, 4, 4),
	(76, 31, 4, 4),
	(77, 32, 4, 4),
	(78, 33, 4, 4),
	(79, 34, 6, 7),
	(80, 35, 6, 7),
	(81, 36, 6, 7),
	(82, 37, 6, 7),
	(83, 38, 6, 7),
	(84, 39, 6, 7),
	(85, 40, 6, 7),
	(86, 41, 6, 7),
	(87, 42, 6, 7),
	(88, 43, 6, 7),
	(89, 44, 6, 7),
	(90, 45, 6, 7),
	(91, 1, 2, 4),
	(92, 2, 2, 4),
	(93, 3, 2, 4),
	(94, 4, 2, 4),
	(95, 5, 2, 4),
	(96, 6, 2, 4),
	(97, 7, 2, 4),
	(98, 8, 2, 4),
	(99, 9, 2, 4),
	(100, 10, 2, 4),
	(101, 11, 2, 4),
	(102, 12, 2, 4),
	(103, 13, 2, 4),
	(104, 14, 2, 4),
	(105, 15, 2, 4),
	(106, 16, 2, 4),
	(107, 17, 2, 4),
	(108, 18, 2, 4),
	(109, 19, 2, 4),
	(110, 20, 2, 4),
	(111, 21, 2, 4),
	(112, 22, 2, 4),
	(113, 23, 2, 4),
	(114, 24, 2, 4),
	(115, 25, 4, 1),
	(116, 26, 4, 1),
	(117, 27, 4, 1),
	(118, 27, 4, 1),
	(119, 29, 4, 1),
	(120, 30, 4, 1),
	(121, 31, 4, 1),
	(122, 32, 4, 1),
	(123, 33, 4, 1),
	(124, 25, 2, 4),
	(125, 26, 2, 4),
	(126, 27, 2, 4),
	(127, 28, 2, 4),
	(128, 29, 2, 4),
	(129, 30, 2, 4),
	(130, 31, 2, 4),
	(131, 32, 2, 4),
	(132, 33, 2, 4),
	(133, 1, 3, 5),
	(134, 2, 3, 5),
	(135, 3, 3, 5),
	(136, 4, 3, 5),
	(137, 5, 3, 5),
	(138, 6, 3, 5),
	(139, 7, 3, 5),
	(140, 8, 3, 5),
	(141, 9, 3, 5),
	(142, 10, 3, 5),
	(143, 11, 3, 5),
	(144, 12, 3, 5),
	(145, 13, 3, 5),
	(146, 14, 3, 5),
	(147, 15, 3, 5),
	(148, 16, 3, 5),
	(149, 17, 3, 5),
	(150, 18, 3, 5),
	(151, 19, 3, 5),
	(152, 20, 3, 5),
	(153, 21, 3, 5),
	(154, 22, 3, 5),
	(155, 23, 3, 5),
	(156, 24, 3, 5),
	(157, 25, 3, 5),
	(158, 26, 3, 5),
	(159, 27, 3, 5),
	(160, 28, 3, 5),
	(161, 29, 3, 5),
	(162, 29, 3, 5),
	(163, 31, 3, 5),
	(164, 32, 3, 5),
	(165, 33, 3, 5),
	(166, 34, 3, 5),
	(167, 35, 3, 5),
	(168, 36, 3, 5),
	(169, 37, 3, 5),
	(170, 38, 3, 5),
	(171, 39, 3, 5),
	(172, 40, 3, 5),
	(173, 41, 3, 5),
	(174, 42, 3, 5),
	(175, 43, 3, 5),
	(176, 44, 3, 5),
	(177, 45, 3, 5);




-- Actualizaciones Lunes, 4 de Diciembre de 2017.
ALTER TABLE `ticket_on_air`
	CHANGE COLUMN `n_json_sectores` `n_json_sectores` LONGTEXT NULL DEFAULT NULL AFTER `n_sectoresdesbloqueados`;
