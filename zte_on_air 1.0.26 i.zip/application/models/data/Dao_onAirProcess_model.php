<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class dao_onAirProcess_model extends CI_Model {

    public function __construct() {
        
    }

    /**
     * En este método obtendremos la lista de los procesos que se estén llevando en el tracking detail.
     */
    public function getProcess() {
        
    }

}
