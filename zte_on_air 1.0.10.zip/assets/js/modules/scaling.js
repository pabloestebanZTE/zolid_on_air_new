var TD = {
    init: function () {
        TD.events();
        TD.configView();
    },
    events: function () {

    },
    onClickItemState: function (e) {

    },
    configView: function () {
        dom.configCalendar($('#txtTimeEscalado'));
    },
    onClickDetails: function () {
        
    },
    getDetails: function () {

    }
};

$(function () {
    TD.init();
})
